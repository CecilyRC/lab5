/*
Names:			Elroy Lobo and Cecily Flores
Lab:			5 - Operator overloading in classes
File name:		bookmain.cpp
Purpose:		The main file with the meat of the code.
				Reads the first and second halves of the library data and prints them.

Psuedocode:		
				1. Open the file "bookdata.txt"
				2. Create/declare an array of 10 book 
				3. Using a loop, read the data of every book into a seperate book object into the newly declared array (setter)
				4. Then, make another loop that prints the data from the array (getter)
				5. Create operator overloaders in book.h that copy book objects, return the isbn number, and compares 2 book objects
				6. In book.h, declare the input and output stream operators
				7. Declare the deconstructor
				8. Modify bookmain.cpp for the 1st 50% of books are read thru the input stream operator overload and written to the console
				9. For the second half of the books, they will be read thru input file method from lab 4 and written to screen using the output stream operator overload
				10. Lastly, using all the constructors in the main, demonstrate the three uses of the member classes
*/

#include <iostream>
#include <fstream>	//Read data
#include <string>	//string to int, stoi
#include <stdlib.h>	//string to double, atof
#include <iomanip>  //formats the output
#include "book.h"	//Include the book header

using namespace std;

int main() {
	string dataFile = "bookdata.txt";
	string rowData;	//String to read if row/line in text

	//Declare a single variable per each of the data to parse
	string isbn = "";	//Naming this data the same as in the 
	string title = "";	//class attributes makes them more readable 
	string author = "";
	string publisher = "";
	string date = "";
	int quantity = 0;
	double cost = 0;
	double price = 0;

	int i = 0;	//Index per each of the row / lines read
	int total = 8;
	int index = 0;	//Index per each element in array

	Book allBooks[10];//Array to store 10 books


	//Reads in data file up to 5 (50%) using 
	cout << "===================================================" << endl;
	cout << "Reads file data using overload operator (first 50%)" << endl;
	cout << "===================================================" << endl;
	ifstream fileHandler(dataFile);	//Create file handler
	if (fileHandler.is_open())
		while (fileHandler.good() && index < 5)     //while there is data
			fileHandler >> allBooks[index++]; //Use overload input stream (file handler is an input stream )



	//Prints first half of data as in lab 4
	cout << "===================================================" << endl;
	std::cout << "Prints array to screen (first 50% as in lab 4)" << endl;
	cout << "===================================================" << endl;
	for (int i = 0; i < 5; i++)
	{
		Book tempBook = allBooks[i];	//Get book 
		cout << "Title: " << tempBook.GetTitle() << endl;
		cout << "Author: " << tempBook.GetAuthor() << endl;
		cout << "ISBN: " << tempBook.GetIsbn() << endl;
		cout << "Publisher: " << tempBook.GetPublisher() << endl;
		cout << "Date: " << tempBook.GetDate() << endl;
		cout << "Quantity: " << tempBook.GetQuantity() << endl;
		cout << "Cost: $" << setprecision(2) << fixed << tempBook.GetCost() << endl;
		cout << "Price: $" << setprecision(2) << fixed << tempBook.GetPrice() << endl;
		cout << endl;
	}




	// Reads in the second half
	cout << "===================================================" << endl;
	cout << "Reads second 50% as in lab 4" << endl;
	cout << "===================================================" << endl;

	if (fileHandler.is_open())
	{
		for (int i = 5; i < 10; i++) {

			string squantity, scost, sprice, garbage;

			getline(fileHandler, title);
			getline(fileHandler, author);
			getline(fileHandler, isbn);
			getline(fileHandler, publisher);
			getline(fileHandler, date);
			getline(fileHandler, squantity);
			quantity = atoi(squantity.c_str());


			getline(fileHandler, scost);
			scost.erase(0, 1);
			cost = atof(scost.c_str());	//c_str converts string to c-like string, char array

			getline(fileHandler, sprice);
			sprice.erase(0, 1);
			price = atof(sprice.c_str());	//c_str converts string to c-like string, char array
			getline(fileHandler, garbage);
			//Create new book on last index 7
			Book tempBook(isbn, title, author, publisher, date, quantity, cost, price);
			//Add it to array starting in 5 and up to 10
			allBooks[index++] = tempBook;
		}
	}
	// prints the error message if the file cant be read
	else std::cout << "Error to read file, " + dataFile;





	// Prints the second half of books using overload
	cout << "===================================================" << endl;
	std::cout << "Prints second 50% of books using overload <<" << endl;
	cout << "===================================================" << endl;
	for (int i = 5; i < 10; i++)
		std::cout << allBooks[i];	//Use overload output





	//Default constructor
	std::cout << "More use of member operators.." << endl;
	std::cout << "Create empty book" << endl;
	Book empty;
	std::cout << empty;


	//Others than title and publisher, everything is garbage value 
	std::cout << "Using constructor with only 2 parameters" << endl;
	Book two("ABC", "Publisher Co.");
	std::cout << two << endl;


	//Single equal check
	std::cout << "Copy first book using assignment operator" << endl;
	Book tempBook = allBooks[0];	//Copy first book
	std::cout << "Isbn as integer (long long, 64 bits): " << (long long)tempBook << endl;	//Uses type cast (int)

	//Double equal check
	if (tempBook == allBooks[0])
		std::cout << "tempBook is equal to first element in array of books (True)" << endl;
	else
		std::cout << "tempBook is not equal to first element in array of books (False)" << endl;

	fileHandler.close();	//Always closes file
	return 0;
}